package com.ava.assistant

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

// IMPORTANT: replace with your deployed backend URL from Railway/Render.
// See backend/README.md for deployment steps.
private const val BACKEND_URL = "https://YOUR-BACKEND-URL.example.com/chat"

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MessageAdapter
    private val messages = mutableListOf<Message>()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerMessages)
        adapter = MessageAdapter(messages)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        addMessage(Message("assistant", "Hi! I'm Ava, an AI assistant. What can I help you with today?"))

        val input: EditText = findViewById(R.id.inputMessage)
        val sendButton: Button = findViewById(R.id.buttonSend)

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            input.setText("")
            addMessage(Message("user", text))
            sendToBackend()
        }
    }

    private fun addMessage(message: Message) {
        adapter.addMessage(message)
        recyclerView.scrollToPosition(messages.size - 1)
    }

    private fun sendToBackend() {
        val messagesJson = JSONArray()
        messages.forEach {
            messagesJson.put(JSONObject().put("role", it.role).put("content", it.content))
        }
        val body = JSONObject().put("messages", messagesJson).toString()

        val request = Request.Builder()
            .url(BACKEND_URL)
            .post(RequestBody.create(MediaType.parse("application/json"), body))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Connection error. Try again.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body()?.string()
                runOnUiThread {
                    if (!response.isSuccessful || responseBody == null) {
                        addMessage(Message("assistant", "Something went wrong. Please try again."))
                        return@runOnUiThread
                    }
                    try {
                        val json = JSONObject(responseBody)
                        val reply = json.optString("reply", "Sorry, I couldn't generate a response.")
                        addMessage(Message("assistant", reply))
                    } catch (e: Exception) {
                        addMessage(Message("assistant", "Something went wrong. Please try again."))
                    }
                }
            }
        })
    }
}
