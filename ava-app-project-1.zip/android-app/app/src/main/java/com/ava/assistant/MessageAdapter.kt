package com.ava.assistant

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MessageAdapter(private val messages: MutableList<Message>) :
    RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val container: LinearLayout = view.findViewById(android.R.id.text1).parent as? LinearLayout
            ?: view as LinearLayout
        val text: TextView = view.findViewById(R.id.textMessage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messages[position]
        holder.text.text = message.content

        val root = holder.text.rootView as? LinearLayout
        val wrapper = holder.text.parent as LinearLayout

        if (message.role == "user") {
            wrapper.gravity = android.view.Gravity.END
            holder.text.setBackgroundResource(R.drawable.bubble_user)
            holder.text.setTextColor(0xFFFFFFFF.toInt())
        } else {
            wrapper.gravity = android.view.Gravity.START
            holder.text.setBackgroundResource(R.drawable.bubble_bot)
            holder.text.setTextColor(0xFF1A1A19.toInt())
        }
    }

    override fun getItemCount() = messages.size

    fun addMessage(message: Message) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }
}
