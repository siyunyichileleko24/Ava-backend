# Ava — path to the Play Store

Everything I can build is done. Here's exactly what's left, in order.

## 1. Deploy the backend (5-10 min)
Go to `backend/README.md` and follow the steps to deploy to Railway or
Render. You'll end up with a URL like:
`https://ava-backend.up.railway.app`

## 2. Point the app at your backend
Open `android-app/app/src/main/java/com/ava/assistant/MainActivity.kt`
and replace:
```kotlin
private const val BACKEND_URL = "https://YOUR-BACKEND-URL.example.com/chat"
```
with your real backend URL + `/chat`.

## 3. Build the app
You'll need Android Studio (free, from developer.android.com/studio).
1. Open the `android-app` folder as a project.
2. Let it sync/download dependencies.
3. Build > Generate Signed Bundle/APK > Android App Bundle (.aab) —
   Android Studio will walk you through creating a signing key
   (keep this key safe; you need the same one for every future update).

## 4. Publish the privacy policy
Take `PRIVACY_POLICY.md`, fill in the bracketed parts, and publish it
somewhere public (GitHub Pages is free and easy). Copy that URL — Play
Console requires it.

## 5. Create your Play Developer account
- Go to play.google.com/console
- Pay the one-time $25 fee
- Verify your identity (Google may take a day or two on this step)

## 6. Create the app listing
In Play Console > Create app, you'll need:
- App name, short description, full description
- Icon (512x512 PNG) and at least 2 screenshots — I can generate these
  once you tell me what look you want
- Privacy policy URL (from step 4)
- Content rating questionnaire (answer honestly — an AI chat app
  usually rates "Teen" or similar due to unpredictable text output)
- Data safety form — declare that you collect user-submitted text and
  share it with Anthropic for processing

## 7. Upload and submit
Upload the `.aab` file from step 3, fill in the remaining listing
fields, and submit for review. Google typically reviews within a few
hours to a few days.

---

## Files in this delivery
- `backend/` — Node.js proxy server (deploy this first)
- `android-app/` — full Android Studio project (Kotlin)
- `PRIVACY_POLICY.md` — fill in and publish before submitting

Let me know when you hit step 3 or 6 and want help with icons,
screenshots, or the app description copy.
