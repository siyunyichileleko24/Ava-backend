# Privacy Policy for Ava

*Last updated: [DATE]*

## What we collect
Ava sends the messages you type to our server, which forwards them to
Anthropic's Claude API to generate a response. We do not require you
to create an account or provide personal information to use the app.

## How we use it
Your messages are used only to generate a reply. We do not sell your
data or use it for advertising.

## Third parties
Message content is sent to Anthropic (the maker of Claude) to generate
responses. See Anthropic's privacy policy at
https://www.anthropic.com/legal/privacy for how they handle data.

## Data retention
[FILL IN: state how long you keep logs/messages on your server, if at
all. If you don't store conversations beyond generating the reply,
say so explicitly here.]

## Children
Ava is not directed at children under 13, and we do not knowingly
collect data from children.

## Contact
Questions about this policy: [YOUR EMAIL]

---
**Before publishing:** Host this file somewhere public (e.g. a GitHub
Pages page, Notion page, or your own website) — Google Play requires
a live URL to your privacy policy, not just a document.
